#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
填空题练习 Android 应用
主程序入口文件
"""

from android_app import PracticeApp

if __name__ == '__main__':
    app = PracticeApp()
    app.run()