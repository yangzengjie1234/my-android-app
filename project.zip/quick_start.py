#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
填空题练习应用 - 快速开始脚本
自动检查环境、安装依赖、运行应用
"""

import os
import sys
import subprocess
import platform

def check_python_version():
    """检查Python版本"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ 错误：需要Python 3.7或更高版本")
        print(f"   当前版本：{version.major}.{version.minor}.{version.micro}")
        return False
    print(f"✅ Python版本检查通过：{version.major}.{version.minor}.{version.micro}")
    
    # 检查字体设置
    check_chinese_font()
    
    return True

def check_chinese_font():
    """检查中文字体设置"""
    print("\n=== 中文字体检查 ===")
    
    # 检查本地字体文件
    local_font = os.path.join("fonts", "NotoSansCJK-Regular.ttf")
    if os.path.exists(local_font):
        print("✅ 找到本地中文字体文件")
        return True
    
    # 检查系统字体
    import platform
    system = platform.system().lower()
    
    if system == 'windows':
        font_paths = [
            'C:/Windows/Fonts/msyh.ttf',  # 微软雅黑
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/simsun.ttc',  # 宋体
        ]
    elif system == 'darwin':  # macOS
        font_paths = [
            '/System/Library/Fonts/STHeiti Medium.ttc',
            '/System/Library/Fonts/PingFang.ttc',
        ]
    else:  # Linux
        font_paths = [
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
        ]
    
    for font_path in font_paths:
        if os.path.exists(font_path):
            print(f"✅ 找到系统中文字体: {os.path.basename(font_path)}")
            return True
    
    print("⚠️ 未找到中文字体，可能无法正确显示中文")
    print("建议运行: python font_setup.py")
    return Falsey
    

def check_pip():
    """检查pip是否可用"""
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      check=True, capture_output=True)
        print("✅ pip检查通过")
        return True
    except subprocess.CalledProcessError:
        print("❌ 错误：pip不可用")
        return False

def install_dependencies():
    """安装项目依赖"""
    dependencies = [
        "kivy>=2.1.0",
        "buildozer>=1.4.0"
    ]
    
    print("📦 开始安装依赖...")
    
    for dep in dependencies:
        try:
            print(f"   安装 {dep}...")
            subprocess.run([sys.executable, "-m", "pip", "install", dep], 
                          check=True, capture_output=True)
            print(f"   ✅ {dep} 安装成功")
        except subprocess.CalledProcessError as e:
            print(f"   ❌ {dep} 安装失败")
            print(f"   错误信息：{e}")
            return False
    
    print("✅ 所有依赖安装完成")
    return True

def check_files():
    """检查必要文件是否存在"""
    required_files = [
        "main.py",
        "android_app.py",
        "buildozer.spec",
        "sample.txt"
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
        else:
            print(f"✅ 找到文件：{file}")
    
    if missing_files:
        print(f"❌ 缺少文件：{', '.join(missing_files)}")
        return False
    
    print("✅ 所有必要文件检查通过")
    return True

def run_app():
    """运行应用"""
    try:
        print("🚀 启动应用...")
        print("   提示：关闭应用窗口即可退出")
        print("   如果出现错误，请检查终端输出")
        print("-" * 50)
        
        subprocess.run([sys.executable, "main.py"], check=True)
        
    except subprocess.CalledProcessError as e:
        print(f"❌ 应用启动失败：{e}")
        return False
    except KeyboardInterrupt:
        print("\n👋 用户中断，应用已退出")
        return True
    
    print("👋 应用已正常退出")
    return True

def show_build_info():
    """显示构建信息"""
    print("\n" + "=" * 60)
    print("📱 Android APK 构建指南")
    print("=" * 60)
    
    print("\n🌐 云端构建（推荐）：")
    print("   1. 将项目推送到GitHub")
    print("   2. GitHub Actions会自动构建APK")
    print("   3. 在Actions页面下载构建好的APK")
    print("   详细步骤请查看：云端构建指南.md")
    
    print("\n💻 本地构建：")
    if platform.system() == "Windows":
        print("   ⚠️  Windows不支持本地构建")
        print("   请使用云端构建或Linux虚拟机")
    else:
        print("   运行命令：buildozer android debug")
        print("   注意：需要安装Android SDK和NDK")
    
    print("\n📖 更多信息：")
    print("   - README.md：项目说明")
    print("   - 云端构建指南.md：详细构建教程")
    print("   - sample.txt：题目格式示例")

def main():
    """主函数"""
    print("🎯 填空题练习应用 - 快速开始")
    print("=" * 40)
    
    # 检查Python版本
    if not check_python_version():
        return 1
    
    # 检查pip
    if not check_pip():
        return 1
    
    # 检查文件
    if not check_files():
        print("\n💡 提示：请确保在项目根目录运行此脚本")
        return 1
    
    # 询问是否安装依赖
    print("\n❓ 是否需要安装/更新依赖？")
    choice = input("   输入 y/yes 安装，其他键跳过：").lower().strip()
    
    if choice in ['y', 'yes', '是', 'Y']:
        if not install_dependencies():
            return 1
    else:
        print("⏭️  跳过依赖安装")
    
    # 询问是否运行应用
    print("\n❓ 是否现在运行应用？")
    choice = input("   输入 y/yes 运行，其他键退出：").lower().strip()
    
    if choice in ['y', 'yes', '是', 'Y']:
        if not run_app():
            return 1
    else:
        print("\n💡 稍后可以运行：python main.py")
    
    # 显示构建信息
    show_build_info()
    
    print("\n🎉 快速开始完成！")
    return 0

if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n👋 用户中断，脚本已退出")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 意外错误：{e}")
        print("请检查错误信息或联系开发者")
        sys.exit(1)