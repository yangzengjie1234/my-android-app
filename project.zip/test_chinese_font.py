#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中文字体测试脚本
用于测试Kivy应用中的中文显示
"""

import os
import sys
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.utils import platform
from kivy.metrics import dp

# 设置窗口大小（仅在桌面测试时有效）
if platform != 'android':
    Window.size = (400, 600)

class ChineseFontTestApp(App):
    def build(self):
        # 注册中文字体
        self.setup_chinese_font()
        
        # 创建主布局
        main_layout = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10))
        
        # 标题
        title = Label(
            text="中文字体测试",
            font_size='24sp',
            font_name='ChineseFont',
            size_hint_y=None,
            height=dp(50)
        )
        main_layout.add_widget(title)
        
        # 测试文本
        test_texts = [
            "这是中文测试文本",
            "填空题练习应用",
            "请先加载题库",
            "练习模式：顺序练习",
            "你的答案：",
            "已答: 0  正确: 0",
            "错题: 0  正确率: 0%",
            "总时间: 00:00"
        ]
        
        for i, text in enumerate(test_texts):
            label = Label(
                text=f"{i+1}. {text}",
                font_size='16sp',
                font_name='ChineseFont',
                size_hint_y=None,
                height=dp(40),
                halign='left'
            )
            label.bind(size=label.setter('text_size'))
            main_layout.add_widget(label)
        
        # 测试按钮
        test_buttons = [
            "📁 加载题库",
            "💾 导出错题",
            "❤️ 收藏",
            "🔄 重置",
            "⬅️ 上一题",
            "下一题 ➡️",
            "✓ 提交",
            "👁 显示答案"
        ]
        
        button_layout = BoxLayout(orientation='vertical', spacing=dp(5))
        for button_text in test_buttons:
            btn = Button(
                text=button_text,
                font_name='ChineseFont',
                size_hint_y=None,
                height=dp(40)
            )
            button_layout.add_widget(btn)
        
        main_layout.add_widget(button_layout)
        
        # 字体状态信息
        font_status = Label(
            text=self.get_font_status(),
            font_size='12sp',
            font_name='ChineseFont',
            size_hint_y=None,
            height=dp(60),
            halign='left'
        )
        font_status.bind(size=font_status.setter('text_size'))
        main_layout.add_widget(font_status)
        
        return main_layout
    
    def setup_chinese_font(self):
        """设置中文字体"""
        try:
            # 尝试使用本地字体文件
            local_font = os.path.join("fonts", "NotoSansCJK-Regular.ttf")
            if os.path.exists(local_font):
                LabelBase.register(name='ChineseFont', fn_regular=local_font)
                print(f"成功注册本地中文字体: {local_font}")
                return
            
            # 尝试注册系统中文字体
            if platform == 'win':
                font_paths = [
                    'C:/Windows/Fonts/msyh.ttf',  # 微软雅黑
                    'C:/Windows/Fonts/simhei.ttf',  # 黑体
                    'C:/Windows/Fonts/simsun.ttc',  # 宋体
                ]
            elif platform == 'android':
                font_paths = [
                    '/system/fonts/NotoSansCJK-Regular.ttc',
                    '/system/fonts/DroidSansFallback.ttf',
                ]
            else:
                font_paths = [
                    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                    '/System/Library/Fonts/STHeiti Medium.ttc',
                ]
            
            for font_path in font_paths:
                if os.path.exists(font_path):
                    LabelBase.register(name='ChineseFont', fn_regular=font_path)
                    print(f"成功注册系统中文字体: {font_path}")
                    return
            
            print("警告: 未找到合适的中文字体")
            
        except Exception as e:
            print(f"字体注册失败: {e}")
    
    def get_font_status(self):
        """获取字体状态信息"""
        status_lines = []
        
        # 检查本地字体
        local_font = os.path.join("fonts", "NotoSansCJK-Regular.ttf")
        if os.path.exists(local_font):
            status_lines.append("✅ 本地字体: 可用")
        else:
            status_lines.append("❌ 本地字体: 不可用")
        
        # 检查系统字体
        if platform == 'win':
            system_fonts = [
                ('微软雅黑', 'C:/Windows/Fonts/msyh.ttf'),
                ('黑体', 'C:/Windows/Fonts/simhei.ttf'),
                ('宋体', 'C:/Windows/Fonts/simsun.ttc')
            ]
        else:
            system_fonts = []
        
        found_system_font = False
        for name, path in system_fonts:
            if os.path.exists(path):
                status_lines.append(f"✅ 系统字体: {name}")
                found_system_font = True
                break
        
        if not found_system_font and system_fonts:
            status_lines.append("❌ 系统字体: 不可用")
        
        return "\n".join(status_lines)

if __name__ == '__main__':
    ChineseFontTestApp().run()