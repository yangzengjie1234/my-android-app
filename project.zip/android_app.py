# -*- coding: utf-8 -*-
# Android版填空题练习软件
# 基于Kivy框架开发

import json
import os
import random
import time
from datetime import datetime
from typing import List, Dict

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.utils import platform
from kivy.core.text import LabelBase
from kivy.resources import resource_find

# 设置窗口大小（仅在桌面测试时有效）
if platform != 'android':
    Window.size = (360, 640)

# 注册中文字体
try:
    # 尝试使用本地字体文件
    local_font = os.path.join("fonts", "NotoSansCJK-Regular.ttf")
    if os.path.exists(local_font):
        LabelBase.register(name='ChineseFont', fn_regular=local_font)
        print(f"成功注册本地中文字体: {local_font}")
    else:
        # 尝试注册系统中文字体
        if platform == 'win':
            # Windows系统字体路径
            font_paths = [
                'C:/Windows/Fonts/msyh.ttf',  # 微软雅黑
                'C:/Windows/Fonts/simhei.ttf',  # 黑体
                'C:/Windows/Fonts/simsun.ttc',  # 宋体
            ]
        elif platform == 'android':
            # Android系统字体路径
            font_paths = [
                '/system/fonts/NotoSansCJK-Regular.ttc',
                '/system/fonts/DroidSansFallback.ttf',
            ]
        else:
            # Linux/Mac系统字体路径
            font_paths = [
                '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                '/System/Library/Fonts/STHeiti Medium.ttc',  # Mac
            ]
        
        # 尝试注册第一个可用的字体
        font_registered = False
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name='ChineseFont', fn_regular=font_path)
                print(f"成功注册系统中文字体: {font_path}")
                font_registered = True
                break
        
        if not font_registered:
            print("警告: 未找到合适的中文字体，可能无法正确显示中文")
            print("建议运行 python font_setup.py 下载中文字体")
except Exception as e:
    print(f"字体注册失败: {e}")
    print("建议运行 python font_setup.py 下载中文字体")

# 简化的文档解析（Android上不支持python-docx）
def parse_simple_text(content: str) -> List[Dict]:
    """解析简单文本格式的题目
    格式：题干______答案
    """
    questions = []
    lines = content.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line or '______' not in line:
            continue
            
        # 查找填空位置
        parts = line.split('______')
        if len(parts) >= 2:
            stem = parts[0] + '______' + '______'.join(parts[2:]) if len(parts) > 2 else parts[0] + '______'
            answer = parts[1].strip()
            if answer:
                questions.append({
                    'stem': stem,
                    'answer': [answer]
                })
    
    return questions

class PracticeApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.questions = []
        self.original_questions = []
        self.wrong_list = []
        self.favorite_list = []
        self.current_index = 0
        self.answered = 0
        self.correct = 0
        
        # 练习模式
        self.practice_mode = "sequential"  # sequential, random, wrong, favorite, study
        self.is_study_mode = False
        
        # 计时相关
        self.start_time = None
        self.total_time = 0
        self.question_start_time = None
        
        # 进度保存
        self.progress_file = "practice_progress.json"
        self.load_progress()
        
        # 定时器事件
        self.timer_event = None
    
    def build(self):
        """构建主界面"""
        main_layout = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(5))
        
        # 顶部工具栏
        toolbar = self.create_toolbar()
        main_layout.add_widget(toolbar)
        
        # 练习模式选择
        mode_layout = self.create_mode_selector()
        main_layout.add_widget(mode_layout)
        
        # 状态显示
        self.status_label = Label(
            text="请先加载题库",
            size_hint_y=None,
            height=dp(30),
            color=(0, 0, 1, 1),
            font_name='ChineseFont'
        )
        main_layout.add_widget(self.status_label)
        
        # 导航栏
        nav_layout = self.create_navigation()
        main_layout.add_widget(nav_layout)
        
        # 题目显示区域
        question_layout = self.create_question_area()
        main_layout.add_widget(question_layout)
        
        # 答案输入区域
        answer_layout = self.create_answer_area()
        main_layout.add_widget(answer_layout)
        
        # 结果显示
        self.result_label = Label(
            text="",
            size_hint_y=None,
            height=dp(40),
            text_size=(None, None),
            font_name='ChineseFont'
        )
        main_layout.add_widget(self.result_label)
        
        # 统计信息
        stats_layout = self.create_stats_area()
        main_layout.add_widget(stats_layout)
        
        # 启动计时器
        self.start_timer()
        
        return main_layout
    
    def create_toolbar(self):
        """创建工具栏"""
        toolbar = GridLayout(cols=3, size_hint_y=None, height=dp(50), spacing=dp(5))
        
        # 文件操作
        load_btn = Button(text="📁 加载题库", on_press=self.load_questions, font_name='ChineseFont')
        toolbar.add_widget(load_btn)
        
        export_btn = Button(text="💾 导出错题", on_press=self.export_wrong, font_name='ChineseFont')
        toolbar.add_widget(export_btn)
        
        help_btn = Button(text="❓ 帮助", on_press=self.show_help, font_name='ChineseFont')
        toolbar.add_widget(help_btn)
        
        return toolbar
    
    def create_mode_selector(self):
        """创建模式选择器"""
        mode_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        
        mode_label = Label(text="练习模式:", size_hint_x=None, width=dp(80), font_name='ChineseFont')
        mode_layout.add_widget(mode_label)
        
        self.mode_spinner = Spinner(
            text="顺序练习",
            values=["顺序练习", "随机练习", "错题练习", "收藏练习", "学习模式"],
            size_hint_x=None,
            width=dp(120),
            font_name='ChineseFont'
        )
        self.mode_spinner.bind(text=self.change_mode)
        mode_layout.add_widget(self.mode_spinner)
        
        # 收藏按钮
        self.favorite_btn = Button(
            text="❤️ 收藏",
            size_hint_x=None,
            width=dp(80),
            on_press=self.toggle_favorite,
            font_name='ChineseFont'
        )
        mode_layout.add_widget(self.favorite_btn)
        
        # 重置按钮
        reset_btn = Button(
            text="🔄 重置",
            size_hint_x=None,
            width=dp(80),
            on_press=self.reset_practice,
            font_name='ChineseFont'
        )
        mode_layout.add_widget(reset_btn)
        
        return mode_layout
    
    def create_navigation(self):
        """创建导航栏"""
        nav_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(50))
        
        # 上一题按钮
        self.prev_btn = Button(
            text="⬅️ 上一题",
            size_hint_x=None,
            width=dp(100),
            on_press=self.prev_question,
            disabled=True,
            font_name='ChineseFont'
        )
        nav_layout.add_widget(self.prev_btn)
        
        # 进度显示
        self.progress_label = Label(text="0/0", font_name='ChineseFont')
        nav_layout.add_widget(self.progress_label)
        
        # 计时显示
        self.timer_label = Label(text="总时间: 00:00", font_name='ChineseFont')
        nav_layout.add_widget(self.timer_label)
        
        # 下一题按钮
        self.next_btn = Button(
            text="下一题 ➡️",
            size_hint_x=None,
            width=dp(100),
            on_press=self.next_question,
            disabled=True,
            font_name='ChineseFont'
        )
        nav_layout.add_widget(self.next_btn)
        
        return nav_layout
    
    def create_question_area(self):
        """创建题目显示区域"""
        question_layout = BoxLayout(orientation='vertical', size_hint_y=0.3)
        
        # 题目标题
        self.question_title = Label(
            text="",
            size_hint_y=None,
            height=dp(30),
            font_size='16sp',
            font_name='ChineseFont'
        )
        question_layout.add_widget(self.question_title)
        
        # 题目内容（可滚动）
        scroll = ScrollView()
        self.question_text = Label(
            text="",
            text_size=(None, None),
            halign='left',
            valign='top',
            font_size='14sp',
            font_name='ChineseFont'
        )
        scroll.add_widget(self.question_text)
        question_layout.add_widget(scroll)
        
        return question_layout
    
    def create_answer_area(self):
        """创建答案输入区域"""
        answer_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(100))
        
        # 答案输入
        input_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        
        answer_label = Label(text="你的答案:", size_hint_x=None, width=dp(80), font_name='ChineseFont')
        input_layout.add_widget(answer_label)
        
        self.answer_input = TextInput(
            multiline=False,
            font_size='14sp',
            font_name='ChineseFont'
        )
        self.answer_input.bind(on_text_validate=self.check_answer)
        input_layout.add_widget(self.answer_input)
        
        submit_btn = Button(
            text="✓ 提交",
            size_hint_x=None,
            width=dp(80),
            on_press=self.check_answer,
            font_name='ChineseFont'
        )
        input_layout.add_widget(submit_btn)
        
        answer_layout.add_widget(input_layout)
        
        # 学习模式专用：显示答案按钮
        self.show_answer_btn = Button(
            text="👁 显示答案",
            size_hint_y=None,
            height=dp(40),
            on_press=self.show_answer,
            font_name='ChineseFont'
        )
        # 初始隐藏
        
        return answer_layout
    
    def create_stats_area(self):
        """创建统计信息区域"""
        stats_layout = GridLayout(cols=2, size_hint_y=None, height=dp(60))
        
        self.answered_label = Label(text="已答: 0", font_name='ChineseFont')
        stats_layout.add_widget(self.answered_label)
        
        self.correct_label = Label(text="正确: 0", font_name='ChineseFont')
        stats_layout.add_widget(self.correct_label)
        
        self.wrong_label = Label(text="错题: 0", font_name='ChineseFont')
        stats_layout.add_widget(self.wrong_label)
        
        self.accuracy_label = Label(text="正确率: 0%", font_name='ChineseFont')
        stats_layout.add_widget(self.accuracy_label)
        
        return stats_layout
    
    def load_questions(self, instance):
        """加载题库"""
        # 创建文件选择弹窗
        content = BoxLayout(orientation='vertical')
        
        # 文件选择器
        filechooser = FileChooserListView(
            filters=['*.txt'],
            path='/sdcard/' if platform == 'android' else '.'
        )
        content.add_widget(filechooser)
        
        # 按钮布局
        btn_layout = BoxLayout(size_hint_y=None, height=dp(50))
        
        load_btn = Button(text="加载")
        cancel_btn = Button(text="取消")
        
        btn_layout.add_widget(load_btn)
        btn_layout.add_widget(cancel_btn)
        content.add_widget(btn_layout)
        
        popup = Popup(
            title="选择题库文件",
            content=content,
            size_hint=(0.9, 0.9)
        )
        
        def load_file(instance):
            if filechooser.selection:
                file_path = filechooser.selection[0]
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    self.questions = parse_simple_text(content)
                    self.original_questions = self.questions.copy()
                    
                    if self.questions:
                        self.current_index = 0
                        self.start_time = time.time()
                        self.refresh_question()
                        self.update_status()
                        self.prev_btn.disabled = False
                        self.next_btn.disabled = False
                        popup.dismiss()
                        self.show_popup("成功", f"已加载 {len(self.questions)} 道题目")
                    else:
                        self.show_popup("警告", "未找到有效题目")
                except Exception as e:
                    self.show_popup("错误", f"加载失败: {str(e)}")
        
        load_btn.bind(on_press=load_file)
        cancel_btn.bind(on_press=popup.dismiss)
        
        popup.open()
    
    def change_mode(self, spinner, text):
        """切换练习模式"""
        mode_map = {
            "顺序练习": "sequential",
            "随机练习": "random",
            "错题练习": "wrong",
            "收藏练习": "favorite",
            "学习模式": "study"
        }
        
        self.practice_mode = mode_map.get(text, "sequential")
        self.is_study_mode = (self.practice_mode == "study")
        
        if not self.original_questions:
            return
        
        if self.practice_mode == "random":
            self.questions = self.original_questions.copy()
            random.shuffle(self.questions)
        elif self.practice_mode == "wrong":
            if self.wrong_list:
                self.questions = [q for q in self.original_questions if q in self.wrong_list]
            else:
                self.show_popup("提示", "暂无错题记录")
                return
        elif self.practice_mode == "favorite":
            if self.favorite_list:
                self.questions = [q for q in self.original_questions if q in self.favorite_list]
            else:
                self.show_popup("提示", "暂无收藏题目")
                return
        else:
            self.questions = self.original_questions.copy()
        
        # 根据模式显示或隐藏答案显示按钮
        if self.is_study_mode:
            if self.show_answer_btn.parent is None:
                # 添加到答案输入区域的父容器
                answer_area = self.answer_input.parent.parent
                answer_area.add_widget(self.show_answer_btn)
        else:
            if self.show_answer_btn.parent:
                self.show_answer_btn.parent.remove_widget(self.show_answer_btn)
        
        self.current_index = 0
        self.refresh_question()
        self.update_status()
    
    def refresh_question(self):
        """刷新题目显示"""
        if not self.questions:
            self.question_title.text = ""
            self.question_text.text = "请先加载题库"
            return
        
        current_q = self.questions[self.current_index]
        self.question_title.text = f"第 {self.current_index + 1} 题"
        self.question_text.text = current_q["stem"]
        self.question_text.text_size = (Window.width - dp(20), None)
        
        # 清空答案输入和结果显示
        self.answer_input.text = ""
        self.result_label.text = ""
        
        # 重置本题计时（学习模式不计时）
        if not self.is_study_mode:
            self.question_start_time = time.time()
        else:
            self.question_start_time = None
        
        self.update_status()
        
        # 聚焦到答案输入框
        self.answer_input.focus = True
    
    def check_answer(self, instance=None):
        """检查答案"""
        if not self.questions:
            return
        
        user_input = self.answer_input.text.strip()
        if not user_input:
            self.show_popup("提示", "请输入答案")
            return
        
        current_q = self.questions[self.current_index]
        correct_answers = current_q["answer"]
        
        # 计算本题用时（学习模式不计时）
        if not self.is_study_mode and self.question_start_time:
            question_time = time.time() - self.question_start_time
            time_text = f" (用时: {self.format_time(question_time)})"
        else:
            time_text = ""
        
        # 检查答案
        is_correct = any(user_input.lower() == ans.lower() for ans in correct_answers)
        
        if is_correct:
            self.result_label.text = f"✅ 正确!{time_text}"
            self.result_label.color = (0, 1, 0, 1)  # 绿色
            self.correct += 1
            # 非学习模式才管理错题列表
            if not self.is_study_mode and current_q in self.wrong_list:
                self.wrong_list.remove(current_q)
        else:
            correct_text = "/".join(correct_answers)
            self.result_label.text = f"❌ 错误! 正确答案: {correct_text}{time_text}"
            self.result_label.color = (1, 0, 0, 1)  # 红色
            # 非学习模式才管理错题列表
            if not self.is_study_mode and current_q not in self.wrong_list:
                self.wrong_list.append(current_q)
        
        self.answered += 1
        self.update_stats()
        
        # 保存进度（学习模式不保存错题记录）
        if not self.is_study_mode:
            self.save_progress()
        
        # 1.5秒后自动下一题
        Clock.schedule_once(self.auto_next, 1.5)
    
    def auto_next(self, dt):
        """自动下一题"""
        if self.current_index < len(self.questions) - 1:
            self.next_question()
        else:
            self.show_completion_stats()
    
    def prev_question(self, instance=None):
        """上一题"""
        if self.current_index > 0:
            self.current_index -= 1
            self.refresh_question()
        else:
            self.show_popup("提示", "已经是第一题了")
    
    def next_question(self, instance=None):
        """下一题"""
        if self.current_index < len(self.questions) - 1:
            self.current_index += 1
            self.refresh_question()
        else:
            self.show_popup("提示", "已经是最后一题了")
    
    def show_answer(self, instance):
        """显示答案（学习模式专用）"""
        if not self.questions:
            return
        
        current_q = self.questions[self.current_index]
        correct_answers = current_q["answer"]
        answer_text = "/".join(correct_answers)
        
        self.result_label.text = f"💡 答案: {answer_text}"
        self.result_label.color = (0, 0, 1, 1)  # 蓝色
    
    def toggle_favorite(self, instance):
        """切换收藏状态"""
        if not self.questions:
            return
        
        current_q = self.questions[self.current_index]
        if current_q in self.favorite_list:
            self.favorite_list.remove(current_q)
            self.favorite_btn.text = "🤍 收藏"
        else:
            self.favorite_list.append(current_q)
            self.favorite_btn.text = "❤️ 已收藏"
        
        self.save_progress()
        self.update_status()
    
    def reset_practice(self, instance):
        """重置练习"""
        self.answered = 0
        self.correct = 0
        self.start_time = time.time() if not self.is_study_mode else None
        self.update_stats()
        self.show_popup("提示", "练习数据已重置")
    
    def export_wrong(self, instance):
        """导出错题"""
        if not self.wrong_list:
            self.show_popup("提示", "暂无错题记录")
            return
        
        try:
            filename = f"错题库_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            filepath = os.path.join('/sdcard/' if platform == 'android' else '.', filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                for i, q in enumerate(self.wrong_list, 1):
                    f.write(f"{i}. {q['stem']}\n")
                    f.write(f"答案: {'/'.join(q['answer'])}\n\n")
            
            self.show_popup("成功", f"错题已导出到: {filename}")
        except Exception as e:
            self.show_popup("错误", f"导出失败: {str(e)}")
    
    def show_help(self, instance):
        """显示帮助"""
        help_text = """📱 Android版填空题练习软件

🔧 使用步骤：
1. 准备txt格式题库文件
2. 题目格式：题干______答案
3. 点击"加载题库"选择文件
4. 选择练习模式开始练习

📚 练习模式：
• 顺序练习：按顺序练习
• 随机练习：随机打乱顺序
• 错题练习：只练习答错的题目
• 收藏练习：只练习收藏的题目
• 学习模式：不计时不统计，可查看答案

💾 数据管理：
• 错题和收藏会自动保存
• 可导出错题到txt文件
• 支持练习进度统计

⏱️ 计时功能：
• 自动记录总练习时间
• 记录每题用时
• 学习模式不计时"""
        
        self.show_popup("帮助", help_text)
    
    def show_completion_stats(self):
        """显示完成统计"""
        if self.answered == 0:
            return
        
        accuracy = (self.correct / self.answered) * 100
        total_time_str = self.format_time(self.total_time) if not self.is_study_mode else "学习模式"
        avg_time = self.total_time / self.answered if self.answered > 0 and not self.is_study_mode else 0
        avg_time_str = self.format_time(avg_time) if not self.is_study_mode else "学习模式"
        
        stats_text = f"""🎉 练习完成！

📊 统计信息：
• 总题数：{len(self.questions)}
• 已答题：{self.answered}
• 正确数：{self.correct}
• 正确率：{accuracy:.1f}%
• 总用时：{total_time_str}
• 平均用时：{avg_time_str}
• 错题数：{len(self.wrong_list)}
• 收藏数：{len(self.favorite_list)}

是否重新开始练习？"""
        
        content = BoxLayout(orientation='vertical')
        content.add_widget(Label(text=stats_text, text_size=(dp(300), None)))
        
        btn_layout = BoxLayout(size_hint_y=None, height=dp(50))
        restart_btn = Button(text="重新开始")
        close_btn = Button(text="关闭")
        
        btn_layout.add_widget(restart_btn)
        btn_layout.add_widget(close_btn)
        content.add_widget(btn_layout)
        
        popup = Popup(
            title="练习完成",
            content=content,
            size_hint=(0.8, 0.8)
        )
        
        def restart(instance):
            self.current_index = 0
            self.refresh_question()
            popup.dismiss()
        
        restart_btn.bind(on_press=restart)
        close_btn.bind(on_press=popup.dismiss)
        
        popup.open()
    
    def update_status(self):
        """更新状态栏"""
        if not self.questions:
            self.status_label.text = "请先加载题库"
            return
        
        mode_text = {
            "sequential": "顺序练习",
            "random": "随机练习",
            "wrong": "错题练习",
            "favorite": "收藏练习",
            "study": "学习模式"
        }.get(self.practice_mode, "顺序练习")
        
        current_q = self.questions[self.current_index]
        is_favorite = "❤️" if current_q in self.favorite_list else "🤍"
        
        progress = f"{self.current_index + 1}/{len(self.questions)}"
        
        if self.is_study_mode:
            self.status_label.text = f"{mode_text} | 进度: {progress} | {is_favorite} | 不计时不统计"
        else:
            self.status_label.text = f"{mode_text} | 进度: {progress} | {is_favorite}"
        
        # 更新进度显示
        self.progress_label.text = progress
        
        # 更新收藏按钮状态
        self.favorite_btn.text = f"{is_favorite} 收藏"
    
    def update_stats(self):
        """更新统计信息"""
        self.answered_label.text = f"已答: {self.answered}"
        self.correct_label.text = f"正确: {self.correct}"
        self.wrong_label.text = f"错题: {len(self.wrong_list)}"
        
        if self.answered > 0:
            accuracy = (self.correct / self.answered) * 100
            self.accuracy_label.text = f"正确率: {accuracy:.1f}%"
        else:
            self.accuracy_label.text = "正确率: 0%"
    
    def start_timer(self):
        """启动计时器"""
        self.timer_event = Clock.schedule_interval(self.update_timer, 1.0)
    
    def update_timer(self, dt):
        """更新计时器显示"""
        if not self.is_study_mode and self.start_time:
            elapsed = time.time() - self.start_time
            self.timer_label.text = f"总时间: {self.format_time(elapsed)}"
        elif self.is_study_mode:
            self.timer_label.text = "学习模式 - 不计时"
        else:
            self.timer_label.text = "总时间: 00:00"
    
    def format_time(self, seconds):
        """格式化时间显示"""
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f"{minutes:02d}:{seconds:02d}"
    
    def load_progress(self):
        """加载进度"""
        try:
            if os.path.exists(self.progress_file):
                with open(self.progress_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.wrong_list = data.get('wrong_list', [])
                    self.favorite_list = data.get('favorite_list', [])
                    self.total_time = data.get('total_time', 0)
        except Exception:
            pass
    
    def save_progress(self):
        """保存进度"""
        try:
            data = {
                'wrong_list': self.wrong_list,
                'favorite_list': self.favorite_list,
                'total_time': self.total_time
            }
            with open(self.progress_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    
    def show_popup(self, title, message):
        """显示弹窗"""
        content = BoxLayout(orientation='vertical')
        content.add_widget(Label(text=message, text_size=(dp(250), None)))
        
        btn = Button(text="确定", size_hint_y=None, height=dp(40))
        content.add_widget(btn)
        
        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.8, 0.6)
        )
        
        btn.bind(on_press=popup.dismiss)
        popup.open()
    
    def on_stop(self):
        """应用关闭时保存进度"""
        self.save_progress()
        if self.timer_event:
            self.timer_event.cancel()

if __name__ == '__main__':
    PracticeApp().run()