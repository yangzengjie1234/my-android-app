#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字体设置辅助脚本
用于下载和配置中文字体
"""

import os
import urllib.request
from kivy.core.text import LabelBase

def download_chinese_font():
    """下载中文字体文件"""
    font_dir = "fonts"
    if not os.path.exists(font_dir):
        os.makedirs(font_dir)
    
    font_file = os.path.join(font_dir, "NotoSansCJK-Regular.ttf")
    
    if not os.path.exists(font_file):
        print("正在下载中文字体...")
        try:
            # 使用Google Fonts的Noto Sans CJK字体
            url = "https://github.com/googlefonts/noto-cjk/raw/main/Sans/OTF/SimplifiedChinese/NotoSansCJK-Regular.otf"
            urllib.request.urlretrieve(url, font_file)
            print(f"字体下载完成: {font_file}")
        except Exception as e:
            print(f"字体下载失败: {e}")
            print("请手动下载中文字体文件到 fonts/ 目录")
            return None
    
    return font_file

def setup_chinese_font():
    """设置中文字体"""
    # 尝试使用本地字体文件
    local_font = os.path.join("fonts", "NotoSansCJK-Regular.ttf")
    if os.path.exists(local_font):
        try:
            LabelBase.register(name='ChineseFont', fn_regular=local_font)
            print(f"成功注册本地中文字体: {local_font}")
            return True
        except Exception as e:
            print(f"本地字体注册失败: {e}")
    
    # 尝试系统字体
    import platform
    system = platform.system().lower()
    
    if system == 'windows':
        font_paths = [
            'C:/Windows/Fonts/msyh.ttf',  # 微软雅黑
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/simsun.ttc',  # 宋体
        ]
    elif system == 'darwin':  # macOS
        font_paths = [
            '/System/Library/Fonts/STHeiti Medium.ttc',
            '/System/Library/Fonts/PingFang.ttc',
        ]
    else:  # Linux
        font_paths = [
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
        ]
    
    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                LabelBase.register(name='ChineseFont', fn_regular=font_path)
                print(f"成功注册系统中文字体: {font_path}")
                return True
            except Exception as e:
                print(f"系统字体注册失败: {e}")
                continue
    
    print("警告: 未找到合适的中文字体，可能无法正确显示中文")
    return False

if __name__ == "__main__":
    # 下载字体（如果需要）
    download_chinese_font()
    
    # 设置字体
    setup_chinese_font()